<script setup>

import AdminLayout from "@/Layouts/AdminLayout.vue";
</script>

<template>
    <AdminLayout>
        <h1>THiis is dashnboard</h1>
    </AdminLayout>
</template>
