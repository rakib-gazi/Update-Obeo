<script setup>

</script>

<template>
    <fwb-input v-model="name" label="Medium" placeholder="enter your name" class="bg-none" />
</template>
