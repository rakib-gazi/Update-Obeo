<?php
return [
    'key' => env('JWT_KEY'),
    'issuer' => env('JWT_ISSUER', 'obeo-app'),
];
